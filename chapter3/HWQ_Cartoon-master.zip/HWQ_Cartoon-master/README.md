# Fun漫画

#### 介绍
漫画软件，API已删除，拿来学方法就行。主要使用kotlin开发，使用MVVM架构,Jsoup爬取网站数据，okhttp请求网络数据，Coil加载网络图片，使用多种Jetpack库，可用于新手学习,viewModel部分比较臃肿，可以拆分到Repository。
[ **Compose版链接** ](https://gitee.com/fanketly/FunCartoon_Compose) 目前只完成一小部分

有什么大bug可以在评论区说。


![输入图片说明](%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20220504114135.jpg)
![输入图片说明](%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20220504111105.jpg)
![输入图片说明](https://images.gitee.com/uploads/images/2021/0421/134949_32a7e9d8_7500578.png "微信截图_20210421134826.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0328/180610_24d02655_7500578.png "微信截图_20210328180533.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0328/180621_c76c870f_7500578.png "微信截图_20210328180455.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0122/160823_9bff749c_7500578.png "微信截图_20210122160031.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0122/160831_b9e0100b_7500578.png "微信截图_20210122160037.png")

package com.example.hwq_cartoon

enum class StateEnum {
    FAIL,
    SUCCESS,
    REFRESH,
    NOTHING
}

package com.example.ui.me

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.base.BaseFragment
import com.example.base.ViewBindingRvAdapter
import com.example.hwq_cartoon.databinding.FragmentBlueToothBinding
import com.example.hwq_cartoon.databinding.RvSettingBinding
import com.example.viewModel.BlueToothViewModel
import com.example.viewModel.MeViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BlueToothFragment : BaseFragment<FragmentBlueToothBinding>() {
    private val meViewModel: MeViewModel by viewModels()
    private val blueToothViewModel: BlueToothViewModel by viewModels()
    private var bluetoothHeadset: BluetoothHeadset? = null
    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HEADSET)
                bluetoothHeadset = proxy as BluetoothHeadset

        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HEADSET)
                bluetoothHeadset = null
        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.btnBlueToothBack.setOnClickListener { remove() }
        if (blueToothViewModel.bluetoothAdapter == null) {
            shortToast("设备不支持蓝牙")
            return
        }
        open()
        blueToothViewModel.bluetoothAdapter!!.getProfileProxy(
            context,
            profileListener,
            BluetoothProfile.HEADSET
        )

        b.rvDevide.layoutManager = LinearLayoutManager(context)
        b.rvDevide.adapter = object :
            ViewBindingRvAdapter<BluetoothDevice, RvSettingBinding>(blueToothViewModel.getPairedDevices()) {
            override fun onBind(b: RvSettingBinding, d: BluetoothDevice, p: Int) {
                b.tvSetting.text = d.name
                b.tvSetting.setOnClickListener {

                }
            }

            override fun onCreateViewHolder(
                parent: ViewGroup,
                viewType: Int
            ): VH<RvSettingBinding> {
                return viewBinding(parent)
            }

        }

    }

    private fun open() {
        if (!blueToothViewModel.getBlueToothStatus()) {
            shortToast("请打开蓝牙")
        }
    }

    override fun onDestroy() {
        meViewModel.bottomLiveData.postValue(false)
        super.onDestroy()
    }

    override fun viewBinding(container: ViewGroup?): FragmentBlueToothBinding {
        return FragmentBlueToothBinding.inflate(layoutInflater)
    }

//    private inner class ConnectThread(device: BluetoothDevice) : Thread() {
//        private val mmSocket: BluetoothSocket? by lazy(LazyThreadSafetyMode.NONE) {
//            device.createRfcommSocketToServiceRecord(MY_UUID)
//        }
//
//        public override fun run() {
//            // 取消发现，否则会减慢连接速度。
//            blueToothViewModel.bluetoothAdapter?.cancelDiscovery()
//
//            mmSocket?.use { socket ->
//                // 通过插座连接到远程设备。此调用会阻塞，直到它成功或引发异常。
//                socket.connect()
//
//                // 连接尝试成功。在单独的线程中执行与连接相关的工作。
//                manageMyConnectedSocket(socket)
//            }
//        }
//
//        // Closes the client socket and causes the thread to finish.
//        fun cancel() {
//            try {
//                mmSocket?.close()
//            } catch (e: IOException) {
//                Log.e(TAG, "Could not close the client socket", e)
//            }
//        }
//    }
}

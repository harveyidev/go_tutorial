package com.example.repository.bean

/**
 * Created by Android Studio.
 * User: HuangWeiQiang
 * Date: 2020/12/22
 * Time: 22:47
 */
data class SpeciesInfo(val id: String, val title: String)
package com.example.viewModel

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.util.Log
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.ViewModel

/**
 *Create by Fanketly on 2022/4/29
 *Gitee:https://gitee.com/fanketly
 */
class BlueToothViewModel @ViewModelInject constructor(
) : ViewModel() {
    private var pairedDevices: Set<BluetoothDevice>? = null
    val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    fun getBlueToothStatus() =
        bluetoothAdapter!!.isEnabled

    fun getPairedDevices(): List<BluetoothDevice> {
        if (pairedDevices == null) {
            pairedDevices = bluetoothAdapter!!.bondedDevices
        }
        Log.i("TAG", "getPairedDevices:${pairedDevices!!.size} ")
        return pairedDevices?.toList() ?: listOf()
    }

}
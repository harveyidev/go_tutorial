package com.example.repository.bean

/**
 * Created by Android Studio.
 * User: HuangWeiQiang
 * Date: 2021/4/6
 * Time: 14:08
 */
data class SettingInfo(val img:Int,val name:String)
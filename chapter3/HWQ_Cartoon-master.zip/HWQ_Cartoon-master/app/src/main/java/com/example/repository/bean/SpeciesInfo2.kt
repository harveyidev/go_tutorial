package com.example.repository.bean

class SpeciesInfo2 : ArrayList<SpeciesInfo2Item>()
package com.example.hwq_cartoon

enum class PagerOrientationEnum(val value: Int) {
    VERTICAL(1),
    HORIZONTAL(2),
    REVERSE_HORIZONTAL(3)
}